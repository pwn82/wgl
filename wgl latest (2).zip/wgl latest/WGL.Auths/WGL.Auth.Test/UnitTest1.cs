namespace WGL.Auth.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            //https://www.youtube.com/watch?v=Hmp2ctGacIo&t=16s
            //https://github.com/JasperKent/WebApi-Integration-Testing
        }
    }
}