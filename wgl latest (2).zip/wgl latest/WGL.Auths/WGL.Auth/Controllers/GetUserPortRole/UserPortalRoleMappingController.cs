﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WGL.Auth.Application.CQRS.Account.Queries.Mapping;
using WGL.Auth.Controllers.BaseController;

namespace WGL.Auth.Controllers.GetUserPortRole
{

    public class UserPortalRoleMappingController : BaseApiController
    {
        //Session Login Token
        [HttpGet("GetUserPortalRoleMapping")]
        public async Task<IActionResult> GetUserPortalRoleMapping(int PortalID,int RoleAccessMappingID,int AccessID, int RoleID,bool IsActive)
        {
            return Ok(await Mediator.Send(new GetUserPortalRoleMappingQuery() {PortalID=PortalID, RoleAccessMappingID= RoleAccessMappingID, AccessID = AccessID, RoleID = RoleID, IsActive= IsActive }));
        }
    }

}
